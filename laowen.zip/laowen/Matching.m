
[p1,p2] = rr_getpath;
if ~strcmp(p2,pwd)
    path(path,pwd);
end
close all
f1 = [num2str(i),'PA-1.jpg'];
f2 = [num2str(i),'PA-2.jpg'];
[I1, I2, f1, f2, pathname] = rr_readimage;%(f1,f2);
w = fspecial('gaussian',[3,3],1);
I1 = imfilter(I1,w,'replicate');
I2 = imfilter(I2,w,'replicate');
[r l] = HPEG(I1, I2);
